﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Diagnostics;
using System.Text;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Content;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Audio;
using System.IO;


namespace Pathfinder
{
    class Dijkstra
    {
        public bool[,] closed;
        public float[,] cost;
        public Coord2[,] link;
        public bool[,] inPath;

        public Dijkstra()
        {
            closed = new bool[40, 40];
            cost = new float[40, 40];
            link = new Coord2[40, 40];
            inPath = new bool[40, 40];
        }

        public void Build(Level level, AiBotBase bot, Player plr)
        {
            for (int i = 0; i < 40; i++)
            {
                for (int j = 0; j < 40; j++)
                {
                    closed[i, j] = false;
                    cost[i, j] = 1000000;
                    link[i, j] = new Coord2(-1, -1);
                    inPath[i, j] = false;
                }
            }

            cost[bot.GridPosition.X, bot.GridPosition.Y] = 0;

            /* --- */

            bool ok = false;
            while (!ok)
            {
                float current = 1000000;
                Coord2 pos = new Coord2(0, 0);

                for (int i = 0; i < 40; i++)
                {
                    for (int j = 0; j < 40; j++)
                    {
                        if (!closed[i, j] & cost[i, j] < current)
                        {
                            System.Console.WriteLine(pos.X + ", " + pos.Y);
                            pos.X = i;
                            pos.Y = j;
                            current = cost[i, j];
                        }
                    }
                }

                closed[pos.X, pos.Y] = true;


                //System.Console.WriteLine(pos.X + ", " + pos.Y);

                if(pos.X == plr.GridPosition.X && pos.Y == plr.GridPosition.Y)
                {
                    ok = true;
                }

                Func(level, pos);

            }
            bool done = false;
            Coord2 nextClose = plr.GridPosition;
            while (!done)
            {
                inPath[nextClose.X, nextClose.Y] = true;
                nextClose = link[nextClose.X, nextClose.Y];
                if (nextClose == bot.GridPosition) done = true;
            }

        }

        public void Func(Level level, Coord2 pos)
        {
            Coord2[] offsets = new Coord2[8]
                {new Coord2(0, 1), new Coord2(0, -1), new Coord2(1, 0), new Coord2(-1, 0),
                 new Coord2(1, 1), new Coord2(1, -1), new Coord2(-1, 1), new Coord2(-1, -1)};
            // 1 = UP, 2 = DOWN, 3 = LEFT, 4 = RIGHT, 5 = UP/RIGHT, 6 = UP/LEFT, 7 = DOWN/RIGHT, 8 = DOWN/LEFT
            for (int i = 0; i < offsets.Length; i++)
            {
                int nX = pos.X + offsets[i].X;
                int nY = pos.Y + offsets[i].Y;
                if(level.ValidPosition(new Coord2 (nX, nY)))
                {
                    float nCost = cost[pos.X, pos.Y];
                    if (i > 3)
                    {
                        nCost = 1.4f;
                    }
                    else
                    {
                        nCost = 1;
                    }
                    if(cost[nX,nY] < nCost)
                    {
                        cost[nX, nY] = nCost;
                        link[nX, nY] = pos;
                    }
                }
            }
        }
    }
}
